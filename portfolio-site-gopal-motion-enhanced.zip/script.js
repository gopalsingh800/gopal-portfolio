// Preloader
window.addEventListener("load", () => {
  const preloader = document.getElementById("preloader");
  setTimeout(() => {
    preloader.classList.add("hidden");
  }, 600); // delay for smoothness
});

// Fade-in animation on scroll with stagger
const sections = document.querySelectorAll('.fade-in, section');
const serviceItems = document.querySelectorAll('.services > div');
const video = document.querySelector('.portfolio video');

const revealOnScroll = () => {
  const triggerBottom = window.innerHeight * 0.85;

  sections.forEach(section => {
    const rect = section.getBoundingClientRect();
    if (rect.top < triggerBottom) {
      section.classList.add('visible');
    }
  });

  // Stagger effect for services
  serviceItems.forEach((item, idx) => {
    const rect = item.getBoundingClientRect();
    if (rect.top < triggerBottom) {
      setTimeout(() => {
        item.classList.add('visible');
      }, idx * 200); // 200ms delay between items
    }
  });

  // Special animation for video
  if (video) {
    const rect = video.getBoundingClientRect();
    if (rect.top < triggerBottom) {
      video.classList.add('visible');
    }
  }
};
window.addEventListener('scroll', revealOnScroll);
revealOnScroll();

// Parallax header background
window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;
  document.querySelector("header").style.backgroundPositionY = `${scrollY * 0.3}px`;
});

// Theme Toggle
const themeToggle = document.getElementById("theme-toggle");

if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("light");
    if (document.body.classList.contains("light")) {
      themeToggle.textContent = "🌞 Light Mode";
    } else {
      themeToggle.textContent = "🌙 Dark Mode";
    }
  });
}
